import React from 'react';

const About = () => {
  return (
  <div>
     <h1>About Us</h1>
      <p>This page provides information about our company and mission.</p>
      {/* Add more details, team info, or images as needed */}
   
  </div>
     
  );
};

export default About;
